<?php
session_start();
$nomeUsuario = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Willian de Sousa Nunes e Dharlan L. Sangi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos/style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/estilos/boxicons.min.css' rel='stylesheet'>
    <script src="https://unpkg.com/scrollreveal"></script>
    <title>WM Turismo - Home</title>
    <style>
        /* Estilo básico para o menu suspenso */
        .user-menu {
            position: relative;
            display: inline-block;
        }

        .user-menu span {
            color: white;
            cursor: pointer;
        }

        .user-menu span:hover {
            color: var(--orange)
        }

        .user-menu .dropdown-content {
            display: none;
            outline: none;
            position: absolute;
            top: 100%;
            right: 0;
            min-width: 150px;
            background-color: var(--verde-escuro);
            box-shadow: 0px 8px 8px;
            z-index: 1;
        }

        .user-menu .dropdown-content a {
            color: white;
            padding: 8px 10px;
            text-decoration: none;
            display: block;
            border-bottom: 1px solid #ddd;
        }

        .user-menu .dropdown-content a:hover {
            color: white;
            background-color: var(--verde);
        }

        /* Exibe o menu ao passar o mouse */
        .user-menu:hover .dropdown-content {
            display: block;
            transition: 0.2s;
        }
    </style>
</head>

<body>
    <a name="topo"></a>
    <div class="background-verde">
        <!-- cabeçalho -->
        <header>
            <!-- container -->
            <div class="container">
                <nav>
                    <div class="logo">
                        <a href="index.php"> WM turismo </a>
                    </div>

                    <ul class="ul">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="servicos.php">Serviços</a></li>
                        <li><a href="quemsomos.php">Quem somos</a></li>
                        <li><a href="contato.php">Contato</a></li>
                        <?php if ($nomeUsuario): ?>
                        <li class="user-menu">
                            <span>
                                <?php echo htmlspecialchars($nomeUsuario); ?>
                            </span>
                            <div class="dropdown-content">
                                <a class="bx bx-user" href="../paginas/perfil_usuario.php">       
                                Sua conta</a>
                                <a class="bx bx-exit" href="../banco/logout.php">       
                                Sair</a>
                            </div>
                        </li>
                        <?php else: ?>
                        <li><a href="logar_usuario.php"><button class="btn-gradiente">Entrar</button></a></li>
                        <?php endif; ?>
                    </ul>
                    <div class="menu-icon">
                        <img src="../imgs/menu.png" alt="ícone de menu">
                    </div>
                </nav>
            </div>
            <!-- fim container -->
        </header>
        <!-- fim cabeçalho -->
        <!-- main/conteudo -->
        <main>
            <!-- container -->
            <div class="container">
                <!-- main text -->
                <div class="main-text">
                    <h1>A terra da aventura te espera!</h1>
                    <h2>Vamos viajar?</h2>
                    <div>
                        <a href="servicos.php"><button class="btn-gradiente">Consultar destinos</button></a>
                        <img src="../imgs/verificado.png" alt="verificado">
                    </div>
                </div>
                <!-- fim main text -->
                <!-- main img -->
                <div class="main-img">
                    <img src="../imgs/Viagem-em-família.jpg" alt="3 homens sorrindo">
                </div>
            </div>
            <!-- fim container -->
        </main>
        <!-- fin main -->
    </div>
    <!-- fim bckg verde -->

    <!-- promocoes -->
    <section class="destaques">
        <div class="container">
            <h2>Ofertas Especiais</h2>
            <p class="subtitulo">Aproveite as melhores promoções e pacotes com preços imperdíveis</p>
            <div class="cards">
                <!-- card item 1 -->
                <div class="card-item-des" style="background-image: url('../imgs/Las-Vegas-USA.jpg');">
                    <h3>Aventuras em Las Vegas</h3>
                    <span class="preco">De <del>R$ 7.500</del> por R$ 6.200</span>

                </div>
                <!-- fim item 1 -->
                <!-- card item 2 -->
                <div class="card-item-des" style="background-image: url('../imgs/toronto-canada.jpg');">
                    <h3>Exploração Urbana - Toronto</h3>
                    <span class="preco">De <del>R$ 4.500</del> por R$ 3.200</span>

                </div>
                <!-- fim item 2 -->
                <!-- card item 3 -->
                <div class="card-item-des" style="background-image: url('../imgs/paris-franca.jpg');">
                    <h3>Belezas de Paris</h3>
                    <span class="preco">De <del>R$ 6.000</del> por R$ 4.500</span>

                </div>
                <!-- fim item 3 -->
            </div>
        </div>
    </section>
    <!-- fim promocoes -->
    <!-- section diferenciais -->
    <section class="diferenciais">
        <div class="container">
            <div class="card">
                <img src="../imgs/medal.png" alt="medalha">
                <h3 class="titulo">Empresa de qualidade</h3>
                <p>
                    Somos uma das principais empresas de turismo do mundo.
                </p>
            </div>
            <div class="card">
                <img src="../imgs/24h.png" alt="24 horas">
                <h3 class="titulo">Atendimento 24h</h3>
                <p>
                    Atendimento 24h para sua viagem ser mais tranquila.
                </p>
            </div>
            <div class="card">
                <img src="../imgs/caixa.png" alt="caixa">
                <h3 class="titulo">Suporte em vários países</h3>
                <p>
                    Suporte em qualquer país ou continente ao redor do mundo.
                </p>
            </div>
        </div>
    </section>
    <!-- fim diferenciais -->
    <!-- section viagem -->
    <section class="viagem">
        <div class="container">
            <div class="viagem-img">
                <img src="../imgs/lugares-para-visistar.png" alt="fotos de viagens">
            </div>
            <div class="viagem-text">
                <h2>Sua felicidade e nosso compromisso!</h2>
                <p>
                    Avaliações de nossos clientes
                </p>
                <img src="../imgs/user-happy.png" alt="usuários">
                <p>
                    <b>+50 aventureiros felizes</b>
                </p>
            </div>
        </div>
    </section>
    <!-- fim viagem -->
    <!-- section newsletter -->
    <section class="newsletter">
        <br>
        <div class="container">
            <div class="box-newsletter">
                <h2>Inscreva-se na nossa newsletter, aventureiro!</h2>
                <p>Se inscreva para receber nossas novidades</p>
                <form action="../banco/newsletter_inscricao.php" method="POST" onsubmit="return inscreverNewsletter(event)">
                    <input type="email" name="email" placeholder="Digite seu melhor email" required>
                    <button type="submit">Inscrever-se</button>
                </form>
                <p id="mensagem"></p>
            </div>
        </div>
        <br>
    </section>
    <!-- fim newsletter -->
    <!-- rodape -->
    <footer>
        <div class="container">
            <!-- ul 1 -->
            <ul>
                <h3>WM Turismo</h3>
                <p>&copy 2024 <br> Todos os direitos reservados</p>
                <div class="redes-sociais">
                    <a href="#"><img src="../imgs/facebook.png" alt="facebook"></a>
                    <a href="#"><img src="../imgs/instagram.png" alt="instagram"></a>
                    <a href="#"><img src="../imgs/linkedin.png" alt="linkedin"></a>
                </div>
            </ul>
            <!-- ul 2 -->
            <ul>
                <h3>Link</h3>
                <li><a href="index.php">home</a></li>
                <li><a href="servicos.php">servicos</a></li>
                <li><a href="quemsomos.php">quem somos</a></li>
                <li><a href="contato.php">contato</a></li>
                <li><a href="#topo">voltar ao topo</a></li>
            </ul>
            <!-- ul 3 -->
            <ul>
                <h3>Nos contate</h3>
                <li>
                    <p><a href="tel:+55 xxxx-xxxx">+55 xxxx-xxxx</a></p>
                </li>
                <li>
                    <p><a href="mailto:email@example.com">email@example.com</a></p>
                </li>
                <li>
                    <p>Brasil</p>
                </li>
            </ul>
        </div>
        <br>
    </footer>
    <!-- fim rodape -->
    <script src="../funcoes/main.js"></script>
</body>

</html>